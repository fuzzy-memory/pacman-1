import java.awt.*;     // Using AWT's Graphics and Color
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.*;  // Using Swing's components and container
import java.util.Random;

/** Test drawImage() thru ImageIcon */
@SuppressWarnings("serial")
public class CGDrawImageDemo extends JFrame {
    // Define constants for the various dimensions
    public static final int ROWS = 3;
    public static final int COLS = 3;
    public static int x= 250;
    public static int y =300;
    public static int xdist= 10;
    public static int ydist =10;
   // public static final int IMAGE_SIZE =;
    public static final int PADDING = 20;  // padding from the border
//    public static final int CELL_SIZE = IMAGE_SIZE + 2 * PADDING;
//    public static final int CANVAS_SIZE = CELL_SIZE * ROWS;

    private DrawCanvas canvas;    // The drawing canvas (an inner class extends JPanel)
    private Random random = new Random(); // for picking images in random

    // Images
    private String imgCrossFilename = "Map.jpg";
    private String imgNoughtFilename = "Map.jpg";
    private Image imgCross;   // drawImage() uses an Image object
    private Image imgNought;

    // Constructor to set up the GUI components and event handlers
    public CGDrawImageDemo() {
        // Prepare the ImageIcon and Image objects for drawImage()
        ImageIcon iconCross = null;
        ImageIcon iconNought = null;
        URL imgURL = getClass().getClassLoader().getResource(imgCrossFilename);
        if (imgURL != null) {
            iconCross = new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + imgCrossFilename);
        }
        imgCross = iconCross.getImage();

        imgURL = getClass().getClassLoader().getResource(imgNoughtFilename);
        if (imgURL != null) {
            iconNought = new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + imgNoughtFilename);
        }
        imgNought = iconNought.getImage();

        canvas = new DrawCanvas();
        canvas.setPreferredSize(new Dimension(500, 600));
        setContentPane(canvas);  // use JPanel as content-pane
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();  // pack the components of "super" JFrame
        setTitle("Test drawImage()");
        setVisible(true);
        ActionListener updateTask = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                update();   // update the (x, y) position
                repaint();  // Refresh the JFrame, callback paintComponent()
            }
        };
        // Allocate a Timer to run updateTask's actionPerformed() after every delay msec
        new Timer(100, updateTask).start();
    }

    public void update() {
        x += xdist;
        y += ydist;
        if (x > 450 || x < 0) {
            xdist = -xdist;
        }
        if (y > 550 || y < 0) {
            ydist = -ydist;
        }
    }
    // Define inner class DrawCanvas, which is a JPanel used for custom drawing
    private class DrawCanvas extends JPanel {
        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            setBackground(Color.BLACK);  // Set background color for this JPanel
            // Drawing Images (picked in random)
            g.drawImage(imgCross,0, 0, 500, 600, null);
            g.drawImage(imgCross,x,y,50,50,null);

        }
    }

    // The entry main method
    public static void main(String[] args) {
        // Run the GUI codes on the Event-Dispatching thread for thread-safety
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CGDrawImageDemo(); // Let the constructor do the job
            }
        });
    }
}