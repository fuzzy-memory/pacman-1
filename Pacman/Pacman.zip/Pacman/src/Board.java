import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.applet.Applet;


public class Board extends Applet implements ActionListener, Runnable {
    private Image image, character, background;
    private Graphics second;
    @Override
    public void init(){
        setFocusable(true);
        Frame frame = (Frame) this.getParent().getParent();
        frame.setTitle("Pacman");
    }
    @Override
    public void actionPerformed(ActionEvent e) {

    }
    @Override
    public void run(){
        while (true) {
            repaint();
            try {
                Thread.sleep(17);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
